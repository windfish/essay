package com.demon.javaagent;

import java.lang.instrument.Instrumentation;

public class Agent {

    public static void premain(String args, Instrumentation instrumentation){
        System.out.println("----------premain 执行------------");
        MainAgent agent = new MainAgent();
        instrumentation.addTransformer(agent);
    }
    
}
