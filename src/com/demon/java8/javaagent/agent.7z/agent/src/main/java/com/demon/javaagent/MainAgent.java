package com.demon.javaagent;

import java.lang.instrument.ClassFileTransformer;
import java.lang.instrument.IllegalClassFormatException;
import java.security.ProtectionDomain;

import javassist.ClassPool;
import javassist.CtClass;
import javassist.CtMethod;

public class MainAgent implements ClassFileTransformer {

    public final String injectedClassName = "com.demon.java8.javaagent.JavaAgent";
    public final String methodName = "hello";
    
    @Override
    public byte[] transform(ClassLoader loader, String className, Class<?> classBeingRedefined,
            ProtectionDomain protectionDomain, byte[] classfileBuffer) throws IllegalClassFormatException {
        String _className = className.replace("/", ".");
        if(_className.equals(injectedClassName)){
            try {
                CtClass ctClass = ClassPool.getDefault().get(_className);
                CtMethod declaredMethod = ctClass.getDeclaredMethod(methodName);
                declaredMethod.insertBefore("System.out.println(\"update class file: 11111111\");");
                declaredMethod.insertAfter("int i = 100;System.out.println(i);");
                return ctClass.toBytecode();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return null;
    }

}
