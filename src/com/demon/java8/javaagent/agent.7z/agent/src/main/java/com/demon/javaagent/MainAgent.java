package com.demon.javaagent;

import java.io.ByteArrayInputStream;
import java.lang.instrument.ClassFileTransformer;
import java.lang.instrument.IllegalClassFormatException;
import java.security.ProtectionDomain;

import javassist.ClassPool;
import javassist.CtClass;
import javassist.CtMethod;

public class MainAgent implements ClassFileTransformer {

    public final String injectedClassName = "com.demon.java8.javaagent.JavaAgent";
    public final String methodName = "hello";
    
    @Override
    public byte[] transform(ClassLoader loader, String className, Class<?> classBeingRedefined,
            ProtectionDomain protectionDomain, byte[] classfileBuffer) throws IllegalClassFormatException {
        ClassPool pool = ClassPool.getDefault();
        /*String _className = className.replace("/", ".");
        if(_className.equals(injectedClassName)){
            try {
                CtClass ctClass = pool.get(_className);
                CtMethod declaredMethod = ctClass.getDeclaredMethod(methodName);
                declaredMethod.insertBefore("System.out.println(\"update class file: 11111111\");");
                declaredMethod.insertAfter("int i = 100;System.out.println(i);");
                return ctClass.toBytecode();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }*/
        if(!className.startsWith("com/demon")){
            return null;
        }
        System.out.println("transform: "+className);
        CtClass c = null;
        try {
            c = pool.makeClass(new ByteArrayInputStream(classfileBuffer));
            if(!c.isInterface()){
                CtMethod[] methods = c.getDeclaredMethods();
                for(CtMethod method: methods){
                    method.insertBefore("System.out.println(\""+c.getName()+"#"+method.getName()+" begin: \" + System.currentTimeMillis() + \" mills.\");");
                    method.insertAfter("System.out.println(\""+c.getName()+"#"+method.getName()+" end: \" + System.currentTimeMillis() + \" mills.\");");
                }
            }
            return c.toBytecode();
        } catch (Exception e) {
            e.printStackTrace();
        }finally{
            if(c != null){
                c.detach();
            }
        }
        return null;
    }

}
